// app/layout.tsx

export const metadata = {
  title: "경제 통합 대시보드",
  description: "글로벌 경제 시장을 한눈에 파악하는 대시보드",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css"
        />
      </head>
      <body style={{
        margin: 0,
        fontFamily: "'Pretendard Variable', -apple-system, BlinkMacSystemFont, sans-serif",
        background: "#F2F4F8",
      }}>
        {children}
      </body>
    </html>
  );
}
