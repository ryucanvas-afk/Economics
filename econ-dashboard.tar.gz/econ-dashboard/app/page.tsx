// app/page.tsx
// 메인 페이지 — 기존 대시보드 UI를 실제 데이터와 연결

"use client";

import React, { useState } from "react";
import { useAllMarketData } from "@/lib/use-market-data";

export default function Home() {
  const { yahoo, naver, crypto, finnhub, fearGreed, isLoading, refetchAll } = useAllMarketData();
  const [view, setView] = useState("dashboard");

  // 로딩 상태
  if (isLoading) {
    return (
      <div style={{ minHeight: "100vh", background: "#F2F4F8", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
        <div style={{ width: 48, height: 48, borderRadius: 16, background: "linear-gradient(135deg,#007AFF,#5856D6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 22, fontWeight: 800 }}>E</div>
        <div style={{ fontSize: 15, fontWeight: 600, color: "#636366" }}>시장 데이터를 불러오는 중...</div>
        <div style={{ width: 200, height: 4, borderRadius: 2, background: "rgba(0,0,0,0.06)", overflow: "hidden" }}>
          <div style={{ width: "60%", height: "100%", borderRadius: 2, background: "#007AFF", animation: "pulse 1.5s ease infinite" }} />
        </div>
        <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}`}</style>
      </div>
    );
  }

  // 디버그용 — 실제 데이터 확인 (개발 중)
  return (
    <div style={{ minHeight: "100vh", background: "#F2F4F8", padding: 24, fontFamily: "'Pretendard Variable', -apple-system, sans-serif" }}>
      <div style={{ maxWidth: 1180, margin: "0 auto" }}>

        {/* 헤더 */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 36, height: 36, borderRadius: 12, background: "linear-gradient(135deg,#007AFF,#5856D6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 16, fontWeight: 800 }}>E</div>
            <div>
              <h1 style={{ fontSize: 17, fontWeight: 800, color: "#1C1C1E", letterSpacing: "-0.03em", margin: 0 }}>경제 통합 대시보드</h1>
              <p style={{ fontSize: 11, color: "#AEAEB2", margin: "2px 0 0" }}>실시간 데이터 연동 확인</p>
            </div>
          </div>
          <button onClick={refetchAll} style={{ padding: "8px 16px", borderRadius: 12, border: "none", background: "#007AFF", color: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
            새로고침
          </button>
        </div>

        {/* 데이터 상태 카드들 */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>

          {/* Yahoo Finance */}
          <DataCard
            title="Yahoo Finance"
            emoji="🌍"
            status={yahoo.data ? "connected" : yahoo.error ? "error" : "loading"}
            error={yahoo.error}
            lastUpdated={yahoo.lastUpdated}
          >
            {yahoo.data && (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {Object.entries(yahoo.data.indices || {}).map(([k, v]: [string, any]) => (
                  <DataRow key={k} label={v.name} value={v.price?.toLocaleString()} change={v.changePercent} />
                ))}
                <div style={{ fontSize: 11, color: "#AEAEB2", marginTop: 4 }}>
                  + 원자재 {Object.keys(yahoo.data.commodities || {}).length}개,
                  환율 {Object.keys(yahoo.data.forex || {}).length}개,
                  채권 {Object.keys(yahoo.data.bonds || {}).length}개
                </div>
              </div>
            )}
          </DataCard>

          {/* 네이버 금융 */}
          <DataCard
            title="네이버 금융"
            emoji="🇰🇷"
            status={naver.data ? "connected" : naver.error ? "error" : "loading"}
            error={naver.error}
            lastUpdated={naver.lastUpdated}
          >
            {naver.data && (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {naver.data.indices?.kospi && (
                  <DataRow label="KOSPI" value={naver.data.indices.kospi.price?.toLocaleString()} change={naver.data.indices.kospi.changePercent} />
                )}
                {naver.data.indices?.kosdaq && (
                  <DataRow label="KOSDAQ" value={naver.data.indices.kosdaq.price?.toLocaleString()} change={naver.data.indices.kosdaq.changePercent} />
                )}
                {naver.data.investors && (
                  <div style={{ marginTop: 4 }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: "#636366", marginBottom: 4 }}>투자자 동향</div>
                    <DataRow label="외국인" value={`${naver.data.investors.foreign?.amount?.toLocaleString()}억`} change={naver.data.investors.foreign?.amount > 0 ? 1 : -1} />
                    <DataRow label="기관" value={`${naver.data.investors.institution?.amount?.toLocaleString()}억`} change={naver.data.investors.institution?.amount > 0 ? 1 : -1} />
                    <DataRow label="개인" value={`${naver.data.investors.retail?.amount?.toLocaleString()}억`} change={naver.data.investors.retail?.amount > 0 ? 1 : -1} />
                  </div>
                )}
                {naver.data.sectors?.length > 0 && (
                  <div style={{ fontSize: 11, color: "#AEAEB2", marginTop: 4 }}>
                    섹터 {naver.data.sectors.length}개 로드됨
                  </div>
                )}
              </div>
            )}
          </DataCard>

          {/* CoinGecko */}
          <DataCard
            title="CoinGecko"
            emoji="₿"
            status={crypto.data ? "connected" : crypto.error ? "error" : "loading"}
            error={crypto.error}
            lastUpdated={crypto.lastUpdated}
          >
            {crypto.data && (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {crypto.data.coins?.map((coin: any) => (
                  <DataRow key={coin.id} label={`${coin.name} (${coin.sub})`} value={`$${coin.price?.toLocaleString()}`} change={coin.change24h} />
                ))}
                {crypto.data.global && (
                  <div style={{ fontSize: 11, color: "#AEAEB2", marginTop: 4 }}>
                    BTC 도미넌스: {crypto.data.global.btcDominance?.toFixed(1)}%
                  </div>
                )}
              </div>
            )}
          </DataCard>

          {/* Finnhub */}
          <DataCard
            title="Finnhub"
            emoji="📅"
            status={finnhub.data ? "connected" : finnhub.error ? "error" : "loading"}
            error={finnhub.error}
            lastUpdated={finnhub.lastUpdated}
          >
            {finnhub.data && (
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <div style={{ fontSize: 12, color: "#636366" }}>
                  경제 이벤트: {finnhub.data.calendar?.length || 0}건
                </div>
                <div style={{ fontSize: 12, color: "#636366" }}>
                  뉴스: {finnhub.data.news?.length || 0}건
                </div>
                {finnhub.data.calendar?.slice(0, 3).map((ev: any, i: number) => (
                  <div key={i} style={{ fontSize: 11, color: "#1C1C1E", padding: "4px 0" }}>
                    <span style={{ color: "#007AFF", fontWeight: 600 }}>{ev.date?.split("T")[0]}</span>{" "}
                    {ev.event} ({ev.country})
                  </div>
                ))}
              </div>
            )}
          </DataCard>

          {/* Fear & Greed */}
          <DataCard
            title="공포 & 탐욕 지수"
            emoji="🧠"
            status={fearGreed.data ? "connected" : fearGreed.error ? "error" : "loading"}
            error={fearGreed.error}
            lastUpdated={fearGreed.lastUpdated}
          >
            {fearGreed.data && (
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{
                  fontSize: 32, fontWeight: 800,
                  color: fearGreed.data.value <= 25 ? "#FF3B30" : fearGreed.data.value <= 50 ? "#FF9500" : fearGreed.data.value <= 75 ? "#FFD60A" : "#34C759",
                }}>
                  {fearGreed.data.value}
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: "#1C1C1E" }}>
                    {fearGreed.data.classification}
                  </div>
                  <div style={{ fontSize: 11, color: "#AEAEB2" }}>
                    {fearGreed.data.value <= 25 ? "극단적 공포" : fearGreed.data.value <= 50 ? "공포" : fearGreed.data.value <= 75 ? "탐욕" : "극단적 탐욕"}
                  </div>
                </div>
              </div>
            )}
          </DataCard>

        </div>

        <div style={{ textAlign: "center", padding: "32px 0", fontSize: 12, color: "#C7C7CC" }}>
          <p>API 연동 확인 완료 후, 기존 대시보드 UI에 실제 데이터를 연결합니다.</p>
          <p style={{ marginTop: 4 }}>v0.5-api — Next.js + Vercel</p>
        </div>
      </div>
    </div>
  );
}

// ── 보조 컴포넌트 ──

function DataCard({ title, emoji, status, error, lastUpdated, children }: {
  title: string; emoji: string; status: "connected" | "error" | "loading";
  error?: string | null; lastUpdated?: string | null; children?: React.ReactNode;
}) {
  const statusColor = status === "connected" ? "#34C759" : status === "error" ? "#FF3B30" : "#FF9500";
  const statusText = status === "connected" ? "연결됨" : status === "error" ? "오류" : "로딩 중";

  return (
    <div style={{
      background: "rgba(255,255,255,0.72)", backdropFilter: "saturate(180%) blur(20px)",
      borderRadius: 20, border: "1px solid rgba(255,255,255,0.85)",
      boxShadow: "0 2px 16px rgba(0,0,0,0.06)", padding: 20,
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 18 }}>{emoji}</span>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#1C1C1E" }}>{title}</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <div style={{ width: 8, height: 8, borderRadius: 4, background: statusColor }} />
          <span style={{ fontSize: 11, fontWeight: 600, color: statusColor }}>{statusText}</span>
        </div>
      </div>
      {error && (
        <div style={{ fontSize: 12, color: "#FF3B30", padding: "8px 12px", background: "rgba(255,59,48,0.06)", borderRadius: 12, marginBottom: 8 }}>
          {error}
        </div>
      )}
      {children}
      {lastUpdated && (
        <div style={{ fontSize: 10, color: "#C7C7CC", marginTop: 8 }}>
          마지막 업데이트: {new Date(lastUpdated).toLocaleTimeString("ko-KR")}
        </div>
      )}
    </div>
  );
}

function DataRow({ label, value, change }: { label: string; value?: string; change?: number }) {
  const isUp = (change || 0) > 0;
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "3px 0" }}>
      <span style={{ fontSize: 12, color: "#636366" }}>{label}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: "#1C1C1E" }}>{value || "—"}</span>
        {change !== undefined && change !== 0 && (
          <span style={{
            fontSize: 11, fontWeight: 600, padding: "2px 6px", borderRadius: 6,
            background: isUp ? "rgba(52,199,89,0.1)" : "rgba(255,59,48,0.1)",
            color: isUp ? "#34C759" : "#FF3B30",
          }}>
            {isUp ? "+" : ""}{typeof change === "number" ? change.toFixed(2) : change}%
          </span>
        )}
      </div>
    </div>
  );
}
